GNE FN STORE — FREE BACKUP EDITION

Purpose:
A safe backup/restore utility for selected Windows gaming-related registry areas.

How to use:
1. Right-click GNE_Backup_Restore.ps1 and choose Run with PowerShell.
2. Choose 1 to create a backup before using any optimization package.
3. Keep the Backup folder somewhere safe.
4. Choose 2 later if you need to restore the saved values.

Important:
- This package does not promise a specific FPS or ping increase.
- Create a restore point before making major Windows changes.
- Close Fortnite before applying system changes.
