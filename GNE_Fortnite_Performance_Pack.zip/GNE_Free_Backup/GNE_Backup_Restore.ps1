# GNE FN Store - Backup & Restore
# Run PowerShell as Administrator.
$ErrorActionPreference = "SilentlyContinue"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Backup = Join-Path $Root "Backup"
New-Item -ItemType Directory -Force -Path $Backup | Out-Null

Write-Host "GNE FN Store - Backup Utility" -ForegroundColor Cyan
Write-Host "1. Create backup"
Write-Host "2. Restore backup"
$choice = Read-Host "Choose"

if ($choice -eq "1") {
    reg export "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" "$Backup\GameDVR.reg" /y | Out-Null
    reg export "HKCU\System\GameConfigStore" "$Backup\GameConfigStore.reg" /y | Out-Null
    reg export "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" "$Backup\VisualEffects.reg" /y | Out-Null
    Write-Host "Backup created in: $Backup" -ForegroundColor Green
} elseif ($choice -eq "2") {
    foreach ($f in @("GameDVR.reg","GameConfigStore.reg","VisualEffects.reg")) {
        $p = Join-Path $Backup $f
        if (Test-Path $p) { reg import $p | Out-Null }
    }
    Write-Host "Backup restored. Restart Windows." -ForegroundColor Green
} else {
    Write-Host "Cancelled."
}
Pause
