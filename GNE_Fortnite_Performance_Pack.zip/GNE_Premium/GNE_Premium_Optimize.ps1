# GNE FN STORE - Premium Safe Gaming Optimization
# Run PowerShell as Administrator.
$ErrorActionPreference = "SilentlyContinue"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Backup = Join-Path $Root "Backup"
New-Item -ItemType Directory -Force -Path $Backup | Out-Null

function Export-Reg($key, $file) {
    reg export $key (Join-Path $Backup $file) /y | Out-Null
}

Write-Host "GNE FN STORE - Premium Optimization" -ForegroundColor Cyan
Write-Host "Creating a backup first..." -ForegroundColor Yellow
Export-Reg "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" "GameDVR.reg"
Export-Reg "HKCU\System\GameConfigStore" "GameConfigStore.reg"

# Disable background Game DVR capture for the current user.
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v AppCaptureEnabled /t REG_DWORD /d 0 /f | Out-Null
reg add "HKCU\System\GameConfigStore" /v GameDVR_Enabled /t REG_DWORD /d 0 /f | Out-Null

# Use Windows' standard Game Mode.
reg add "HKCU\Software\Microsoft\GameBar" /v AutoGameModeEnabled /t REG_DWORD /d 1 /f | Out-Null

Write-Host ""
Write-Host "Optimization applied." -ForegroundColor Green
Write-Host "A backup was saved in: $Backup"
Write-Host "Restart Windows for the changes to fully take effect."
Pause
