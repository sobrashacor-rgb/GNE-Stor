# GNE FN STORE - Premium Restore
# Run PowerShell as Administrator.
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Backup = Join-Path $Root "Backup"

foreach ($f in @("GameDVR.reg","GameConfigStore.reg")) {
    $p = Join-Path $Backup $f
    if (Test-Path $p) { reg import $p | Out-Null }
}

Write-Host "GNE Premium backup restored. Restart Windows." -ForegroundColor Green
Pause
