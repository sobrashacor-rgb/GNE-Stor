GNE FN STORE — PREMIUM FORTNITE PERFORMANCE

Included:
- GNE_Premium_Optimize.ps1
- GNE_Premium_Restore.ps1
- Automatic registry backup before applying changes

How to use:
1. Close Fortnite and other games.
2. Run GNE_Premium_Optimize.ps1 as Administrator.
3. The package creates a Backup folder automatically.
4. Restart Windows.
5. If needed, run GNE_Premium_Restore.ps1 as Administrator.

Notes:
- This is a conservative Windows optimization package.
- Results vary by PC and Windows configuration.
- No guaranteed FPS, input-lag, or ping improvement is promised.
- Do not use multiple Windows optimization packs simultaneously.
